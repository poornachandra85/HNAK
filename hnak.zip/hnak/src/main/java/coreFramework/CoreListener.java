package coreFramework;

import org.testng.IClass;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;


/**
 * This class consists of all listners to TestNG
 * 
 * @author  Poornachandra
 * @version 1.0
 * @since   14-Dec-2015 
 */
public class CoreListener extends TestListenerAdapter {
	
	static String testCaseNameListner;
	static String MethodName;
	/**
	   * This method is used to get the test case details
	   * 
	   * @author Poornachandra
	   */
	@Override
	public void onTestStart(ITestResult result) {

		  testCaseNameListner = result.getTestClass().getTestName();
		  

		}
	public void onTestMethodStart(ITestResult result) {

		MethodName = result.getTestClass().getTestName();

		}

}