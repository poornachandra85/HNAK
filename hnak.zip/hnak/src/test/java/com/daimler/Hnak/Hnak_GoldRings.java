package com.daimler.Hnak;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.SkipException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


import coreFramework.ExcelUtil;

public class Hnak_GoldRings {
	String className = this.getClass().getSimpleName();
	public static WebDriver Webdriver;
	public  Properties property=new Properties();
	public  Properties ObjectProperty=new Properties();

	@BeforeTest
	public void beforeTest() throws IOException {
		FileInputStream fis=new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\testArtifacts\\Config.properties");
		property.load(fis);
		FileInputStream Objfis=new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\testArtifacts\\ObjectRepository.properties");
		ObjectProperty.load(Objfis);
		ExcelUtil.strFile = property.getProperty("TestDataFileName");
	}

	@Test
	public void testFlow(Method testMethod) throws IOException, InterruptedException {
		boolean execute = ExcelUtil.getDataFromExcel(className, "Execute")
				.equalsIgnoreCase("Y");
		if (execute) {
			try {
				Process process = Runtime.getRuntime().exec("taskkill /f /im chrome.exe");
				try {
					process.waitFor();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				Process process1 = Runtime.getRuntime().exec("taskkill /f /im chromedriver.exe");
				String chromeDriverPath = System.getProperty("user.dir")
						+ "\\src\\main\\resources\\chromedriver_2.28_win32\\chromedriver.exe";
				System.setProperty("webdriver.chrome.driver", chromeDriverPath);
				HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
				chromePrefs.put("profile.default_content_settings.popups", 0);
				ChromeOptions options = new ChromeOptions();
				options.addArguments("no-sandbox");
				options.addArguments("disable-extensions");
				options.addArguments("disable-infobars");
				options.addArguments("--disable-notifications");
				options.addArguments("--disable-popup-blocking");
				options.setExperimentalOption("prefs", chromePrefs);
				options.setExperimentalOption("useAutomationExtension", false);
				DesiredCapabilities cap = DesiredCapabilities.chrome();
				cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				cap.setCapability(ChromeOptions.CAPABILITY, options);
				Webdriver = new ChromeDriver(cap);
				Webdriver.manage().window().maximize();
	            Thread.sleep(2000);
	            Webdriver.get(property.getProperty("url"));
	            Thread.sleep(3000);
	            System.out.println(Webdriver.getTitle());
	            Webdriver.navigate().refresh();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
			}
		} else {
			new SkipException("Test scriptit is not selected to execute");
		}
	}
}
